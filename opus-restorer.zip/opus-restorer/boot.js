(function(){
var d={e:true,o:true,h:false};
try{var s=localStorage.getItem("_at");if(s)d=Object.assign(d,JSON.parse(s));}catch(x){}
var t=document.createElement("script");
t.textContent="window._ac="+JSON.stringify(d)+";";
(document.documentElement||document).prepend(t);
t.remove();
if(chrome.storage&&chrome.storage.sync){
chrome.storage.sync.get(d,function(r){localStorage.setItem("_at",JSON.stringify(r));});
chrome.storage.onChanged.addListener(function(c,a){if(a==="sync"){try{var cur=JSON.parse(localStorage.getItem("_at")||"{}");for(var k in c)cur[k]=c[k].newValue;localStorage.setItem("_at",JSON.stringify(cur));}catch(x){}}});
}
chrome.runtime&&chrome.runtime.onMessage&&chrome.runtime.onMessage.addListener(function(m,s,r){
if(m.t==="g"){try{var s=localStorage.getItem("_at");r(s?JSON.parse(s):d);}catch(x){r(d);}return true;}
if(m.t==="s"){try{var cur=JSON.parse(localStorage.getItem("_at")||"{}");Object.assign(cur,m.d);localStorage.setItem("_at",JSON.stringify(cur));if(chrome.storage&&chrome.storage.sync)chrome.storage.sync.set(cur);}catch(x){}r({ok:1});return true;}
});
})();