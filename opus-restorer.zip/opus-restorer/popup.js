(function(){
var df={e:true,o:true,h:false};
var el={e:document.getElementById("e"),o:document.getElementById("o"),h:document.getElementById("h")};
var rl=document.getElementById("rl");
function load(){
chrome.storage&&chrome.storage.sync?chrome.storage.sync.get(df,function(r){
el.e.checked=r.e;el.o.checked=r.o;el.h.checked=r.h;
}):Object.keys(df).forEach(function(k){el[k].checked=df[k];});
}
function save(k,v){
var d={};d[k]=v;
if(chrome.storage&&chrome.storage.sync)chrome.storage.sync.set(d);
chrome.tabs.query({active:true,currentWindow:true},function(t){
if(t[0])chrome.tabs.sendMessage(t[0].id,{t:"s",d:d});
});
rl.classList.add("v");
}
Object.keys(el).forEach(function(k){
el[k].addEventListener("change",function(){save(k,this.checked);});
});
rl.addEventListener("click",function(){
chrome.tabs.query({active:true,currentWindow:true},function(t){if(t[0])chrome.tabs.reload(t[0].id);});
});
load();
})();