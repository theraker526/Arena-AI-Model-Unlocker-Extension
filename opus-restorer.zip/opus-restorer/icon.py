import struct,zlib,math
def mk(sz):
 px=[]
 c=sz/2;ro=sz*0.42;ri=sz*0.24;rb=sz*0.46
 for y in range(sz):
  r=[]
  for x in range(sz):
   dx,dy=x-c+.5,y-c+.5;d=math.sqrt(dx*dx+dy*dy)
   if d<=rb:
    t=d/rb;br,bg,bb=int(88+(30-88)*t),int(28+(10-28)*t),int(135+(60-135)*t)
    if ri<=d<=ro:
     rt=abs(d-(ri+ro)/2)/((ro-ri)/2);g=max(0,1-rt*1.2)
     r+=[min(255,int(br+(255-br)*g)),min(255,int(bg+(255-bg)*g)),min(255,int(bb+(255-bb)*g)),255]
    else:r+=[br,bg,bb,255]
   elif d<=rb+2:r+=[88,28,135,max(0,min(255,int(255*(rb+2-d)/2)))]
   else:r+=[0,0,0,0]
  px.append(bytes(r))
 raw=b''
 for row in px:raw+=b'\x00'+row
 def ch(t,d):c=t+d;return struct.pack('>I',len(d))+c+struct.pack('>I',zlib.crc32(c)&0xFFFFFFFF)
 return b'\x89PNG\r\n\x1a\n'+ch(b'IHDR',struct.pack('>IIBBBBB',sz,sz,8,6,0,0,0))+ch(b'IDAT',zlib.compress(raw,9))+ch(b'IEND',b'')
for s in[48,128]:open(f'icon{s}.png','wb').write(mk(s))